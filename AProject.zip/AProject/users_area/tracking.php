<h3 class="text-center text-success">All Products</h3>
<table class="table table-bordered mt-5">
<thead class="bg-info">
<th>Sr.no</th>
<th>Order ID</th>
<th>Invoice Number</th>
<th>Order Date</th>
<th>Status</th>
<th>Product Location</th>
</thead>
<tbody class="bg-secondary text-light">
    <?php
    $get_products="Select * from `user_orders`";
    $result=mysqli_query($con,$get_products);
    $number=0;
    while($row=mysqli_fetch_assoc($result)){
        $order_id=$row['order_id'];
        $invoice_number=$row['invoice_number'];
        $order_date=$row['order_date'];
        $status=$row['order_status'];
        $product_location=$row['product_location'];
        $number++;
        ?>
        <tr class='text-center'>
        <td><?php echo $number ?></td>
        <td><?php echo $order_id ?></td>
        <td><?php echo $invoice_number ?></td>
        <td><?php echo $order_date ?></td>  
        <td>Payment Status <?php echo $status ?></td>   
        <td><?php echo $product_location ?></td>  
        </td>
    </tr>
    <?php
    }
    ?>
</tbody>
</table>