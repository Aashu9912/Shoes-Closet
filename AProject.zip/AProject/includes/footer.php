<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=0.7">
<title>Your Page Title</title>
<style>
  body {
    margin: 0;
    padding: 0;
    display: flex;
    flex-direction: column; /* Ensure page takes at least the full viewport height */
  }
  .content {
    flex: 1; /* Allow content to grow and push footer to the bottom */
  }
  .footer {
    background-color: #f8f9fa;
        text-align: center;
    position: fixed;
    width: 100%;
    bottom: 0;
  }
</style>
</head>
<body>
  <div class="content">
    <!-- Your page content here -->
    <!-- Make sure your content is large enough to push footer down -->
  </div>
  <div class="footer">
    <div class="bg-info p-0 text-center">
      <p>All Rights Reserved ©- Anchal Mishra & Aashish Pandey-2023/24</p>
    </div>
  </div>
</body>
</html>
