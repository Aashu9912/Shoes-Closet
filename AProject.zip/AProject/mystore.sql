-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 17, 2024 at 07:07 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mystore`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_table`
--

CREATE TABLE `admin_table` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `admin_email` varchar(255) NOT NULL,
  `admin_password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_table`
--

INSERT INTO `admin_table` (`admin_id`, `admin_name`, `admin_email`, `admin_password`) VALUES
(1, 'admin', 'admin@gmail.com', '$2y$10$jLbC9rprYpwuoZQEs0kBYeKuic5pAsU/DbPEomn4SnSMmqdvJM8IG');

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `brand_id` int(11) NOT NULL,
  `brand_title` varchar(100) NOT NULL,
  `brand_contact_details` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`brand_id`, `brand_title`, `brand_contact_details`) VALUES
(1, 'Reebok', '0'),
(2, 'Nike', '0'),
(3, 'Adidas ', '0'),
(4, 'Skechers', '0'),
(5, 'Woodland', '0'),
(8, 'dummy1', '');

-- --------------------------------------------------------

--
-- Table structure for table `cart_details`
--

CREATE TABLE `cart_details` (
  `product_id` int(11) NOT NULL,
  `ip_address` varchar(255) NOT NULL,
  `quantity` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `category_title` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_title`) VALUES
(1, 'Mens Shoes'),
(2, 'Womens Shoes'),
(3, 'Kids Shoes'),
(8, 'dummy1');

-- --------------------------------------------------------

--
-- Table structure for table `pending_orders`
--

CREATE TABLE `pending_orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `invoice_number` int(255) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(255) NOT NULL,
  `order_status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pending_orders`
--

INSERT INTO `pending_orders` (`order_id`, `user_id`, `invoice_number`, `product_id`, `quantity`, `order_status`) VALUES
(1, 1, 1226001653, 17, 1, 'pending'),
(2, 1, 1194387899, 15, 1, 'pending'),
(3, 1, 784681734, 18, 2, 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `product_title` varchar(100) NOT NULL,
  `product_description` varchar(1000) NOT NULL,
  `products_keywords` varchar(1000) NOT NULL,
  `shoe_sizes1` varchar(255) NOT NULL,
  `shoe_sizes2` varchar(255) NOT NULL,
  `category_id` int(11) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `product_image1` varchar(255) NOT NULL,
  `product_image2` varchar(255) NOT NULL,
  `product_image3` varchar(255) NOT NULL,
  `product_price` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_title`, `product_description`, `products_keywords`, `shoe_sizes1`, `shoe_sizes2`, `category_id`, `brand_id`, `product_image1`, `product_image2`, `product_image3`, `product_price`, `date`, `status`) VALUES
(1, 'Air Jordan 1 Low SE Craft', 'Dark, stormy and full of style. This AJ1 combines leather, suede and textiles in the upper for a tonal look with plenty of depth.', 'Color Shown: Dark Smoke Grey/Varsity Red/Black', 'UK-8', 'UK-7', 1, 2, 'air-jordan-1-low-se-craft-shoes-76v7Vm.jpg', 'air-jordan-1-low-se-craft-shoes-76v7Vm (2).jpg', 'air-jordan-1-low-se-craft-shoes-76v7Vm (1).jpg', '10295', '2024-02-23 15:03:17', 'true'),
(3, 'Air Dunk Jumbo', 'Your favourite look goes big and bold. Extra-large branding exaggerates the classic look, while the Air strobel unit puts cushioning right beneath your feet.', 'Colour Shown: Black/White', 'UK-9', 'UK-7', 1, 2, 'air-dunk-jumbo-shoes-wc8JrQ.png', 'air-dunk-jumbo-shoes-wc8JrQ (2).png', 'air-dunk-jumbo-shoes-wc8JrQ (1).png', '11495', '2024-02-23 15:03:28', 'true'),
(4, 'Air Max 90 LV8 SE', 'The Air Max 90 LV8 SE takes your favorite silhouette to the next level with stacked Nike Air units.', 'Colour Shown: Sail/Adobe/Medium Soft Pink/Dark Team Red', 'UK-10', 'UK-7', 2, 2, 'air-max-90-lv8-se-shoes-GcKBMK.png', 'air-max-90-lv8-se-shoes-GcKBMK.jpg', 'air-max-90-lv8-se-shoes-GcKBMK (1).png', '13995', '2024-02-23 15:06:42', 'true'),
(5, 'Air Max 97', 'Originally made for running, the 97 is now a pair of kicks you can rock anywhere, any day of the week.', 'Color Shown: Metallic Gold/Black/White/Varsity Red/kids', 'UK-4', 'UK-7', 3, 2, 'air-max-97-older-shoes-8bKSwF.png', 'air-max-97-older-shoes-8bKSwF (1).png', 'air-max-97-older-shoes-8bKSwF.jpg', '12995', '2024-02-23 15:06:42', 'true'),
(9, 'SAMBA OG SHOES', 'Born on the pitch, the Samba is a timeless icon of street style.', 'Color: Core Black / Cloud White / Gum', 'UK-10', 'UK-7', 1, 3, 'Samba_OG_Shoes_Black_B75807_01_standard.jpg', 'Samba_OG_Shoes_Black_B75807_04_standard.jpg', 'Samba_OG_Shoes_Black_B75807_05_standard.jpg', '10999', '2024-02-23 15:06:42', 'true'),
(10, 'SUPERSTAR XLG SHOES', 'When you thought the adidas Superstar shoes could not get any bolder, this pair amplifies the classic 70s trainer for modern fashion.', 'Color: Cloud White / Core Black / Gold Metallic', 'UK-9', 'UK-8', 1, 3, 'Superstar_XLG_Shoes_White_IF9995_02_standard_hover.jpg', 'Superstar_XLG_Shoes_White_IF9995_04_standard.jpg', 'Superstar_XLG_Shoes_White_IF9995_09_standard.jpg', '11999', '2024-02-28 14:32:09', 'true'),
(11, '4DFWD 3 RUNNING SHOES', 'Whether you are focused on your next stride or the finish line, running is all about moving forward.', 'Color: Dash Grey / Silver Violet / Lucid Lemon', 'UK-6', 'UK-7', 2, 3, '4DFWD_3_Running_Shoes_Grey_IG8993_HM1.jpg', '4DFWD_3_Running_Shoes_Grey_IG8993_HM3_hover.jpg', '4DFWD_3_Running_Shoes_Grey_IG8993_HM4.jpg', '21999', '2024-02-23 15:06:42', 'true'),
(12, 'GAZELLE SHOES', 'The original Gazelle first made its mark as a multipurpose training shoe and is now a beloved streetwear classic.', 'Color- Core Black / Cloud White / Gold Metallic', 'UK-2.5', 'UK-7', 3, 3, 'Gazelle_Shoes_Black_BB2502_01_standard.jpg', 'Gazelle_Shoes_Black_BB2502_02_standard_hover.jpg', 'Gazelle_Shoes_Black_BB2502_04_standard.jpg', '7599', '2024-02-23 15:06:42', 'true'),
(13, 'POWER - FLEETZ', 'Add more response and cushion to your run with the Skechers GOrun Power. Features lightweight, responsive ULTRA FLIGHT cushioning for maximum comfort.', 'Color-Black/White & Neon Green', 'UK-6', 'UK-7', 2, 4, '194880322052-1.jpg', '194880322052-2.jpg', '194880322052-3.jpg', '9999', '2024-02-23 15:06:42', 'true'),
(14, 'GO RUN RIDE 11', 'Get ready to move in lightweight supportive comfort with Skechers GO RUN Ride 11.', 'Color-Black/White', 'UK-11', 'UK-7', 1, 4, '196642718288-1.jpg', '196642718288-2.jpg', '196642718288-3.jpg', '13999', '2024-02-23 15:06:42', 'true'),
(15, 'REEBOK MEN ZIG KINETICA 2 5 EDGE RUNNING SHOES', '3M Thinsulate:3M Thinsulate Linier Provides Lightweight Thermal Management. Elastic Lace: Designed To Make It Easy To Put The Shoe On', 'Color: Grey', 'UK-10.5', 'UK-7', 1, 1, '928584-11750320.jpg', '928584-11750321.jpg', '928584-11750323.jpg', '16999', '2024-02-23 15:06:42', 'true'),
(16, 'REEBOK BOYS CLASSIC LEATHER FOOTWEAR', 'Kids 2023:Eva Midsole And Rubber Outsole. Kids 2023:Leather Upper', 'Color: White', 'UK-4.5', 'UK-7', 3, 1, '865956-10257154jpg.avif', '865956-10257158.jpg', '865956-10257160.jpg', '3999', '2024-02-23 15:06:42', 'true'),
(17, 'REEBOK WOMEN FLOATRIDE ENERGY 4 ADVENTURE RUNNING SHOES', 'ROAD-TO-TRAIL RUNNING SHOES, PART OF REEBOKS [REE]CYCLED COLLECTION  Run to the end of the road and just keep going.', 'Color: Brown', 'UK-5.5', 'UK-7', 2, 1, '867591-10287956.jpg', '867591-10287955.jpg', '867591-10287958.jpg', '15999', '2024-02-23 15:06:42', 'true'),
(18, 'ULTRA FLEX 3.0-COZY STREAK', 'TOUCHLESS FIT Feet forward comfort and sleek sporty style combine in Skechers Hands Free Slip-ins: Ultra Flex 3.0 - Cozy Streak. Designed with a unique Comfort Pillow in the heel.', 'Color-Black/Golden', 'UK-8', 'UK-7', 1, 4, '196642197250-1.jpg', '196642197250-2.jpg', '196642197250-3.jpg', '7499', '2024-02-23 15:06:42', 'true'),
(19, 'REEBOK WOMEN ZIG DYNAMICA 4 RUNNING SHOES', 'Cushion In Heel:Extra Padding In Heel For Ultimate Comfort. Fuelfoam Imeva:Our Soft Eva Compound That Balances First Feel Cushioning With Responsiveness.', 'Color: Beige', 'UK-4', 'UK-7', 2, 1, '928582-11750274.jpg', '928582-11750275.jpg', '928582-11750276.jpg', '8599', '2024-02-23 15:06:42', 'true'),
(20, 'Jordan Stadium 90', 'Comfort is king, but that does not mean you have to sacrifice style.', 'Colour Shown: White/Vapour Green/Taxi/Dark Powder Blue', 'UK_3', 'UK-7', 3, 2, 'jordan-stadium-90-older-shoes-2J5HrK.jpg', 'jordan-stadium-90-older-shoes.jpg', 'jordan-stadium-90-older-shoes-.jpg', '7995', '2024-02-23 15:06:42', 'true');

-- --------------------------------------------------------

--
-- Table structure for table `user_orders`
--

CREATE TABLE `user_orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount_due` int(255) NOT NULL,
  `invoice_number` int(255) NOT NULL,
  `total_products` int(255) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `order_status` varchar(255) NOT NULL,
  `product_location` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_orders`
--

INSERT INTO `user_orders` (`order_id`, `user_id`, `amount_due`, `invoice_number`, `total_products`, `order_date`, `order_status`, `product_location`) VALUES
(1, 1, 12995, 1535394415, 1, '2024-03-14 05:54:35', 'Complete', 'Way To Your Home'),
(3, 1, 16994, 1733688966, 2, '2024-03-14 05:55:05', 'Complete', 'Dispatched From Delhi'),
(4, 1, 11495, 1317809365, 1, '2024-03-14 05:55:08', 'Complete', 'Currently In Mumbai Transit '),
(5, 1, 24994, 1006296229, 2, '2024-03-14 05:39:04', 'Complete', ''),
(6, 1, 15999, 1226001653, 1, '2024-03-12 16:01:26', 'Complete', ''),
(7, 1, 16999, 1194387899, 1, '2024-03-14 05:39:40', 'Complete', '');

-- --------------------------------------------------------

--
-- Table structure for table `user_payments`
--

CREATE TABLE `user_payments` (
  `payment_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `invoice_number` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `payment_mode` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_payments`
--

INSERT INTO `user_payments` (`payment_id`, `order_id`, `invoice_number`, `amount`, `payment_mode`, `date`) VALUES
(1, 4, 1317809365, 11495, 'UPI', '2024-03-11 16:58:20'),
(2, 1, 1535394415, 12995, 'Cash On Delivery', '2024-03-11 17:02:48'),
(3, 3, 1733688966, 16994, 'UPI', '2024-03-11 17:03:52'),
(4, 3, 1733688966, 16994, 'UPI', '2024-03-11 17:04:19'),
(5, 6, 1226001653, 15999, 'Netbanking', '2024-03-12 16:01:26'),
(7, 7, 1194387899, 16999, 'Pay Offline', '2024-03-14 05:39:40'),
(8, 8, 784681734, 14998, 'Netbanking', '2024-03-17 08:58:37');

-- --------------------------------------------------------

--
-- Table structure for table `user_table`
--

CREATE TABLE `user_table` (
  `user_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_image` varchar(255) NOT NULL,
  `user_ip` varchar(100) NOT NULL,
  `user_address` varchar(255) NOT NULL,
  `user_mobile` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_table`
--

INSERT INTO `user_table` (`user_id`, `username`, `user_email`, `user_password`, `user_image`, `user_ip`, `user_address`, `user_mobile`) VALUES
(1, 'Aashu', 'Aashu@gmail.com', '$2y$10$rmv1ks56TYGSUGbBuMohielUpuggZjO9Mx9Aw15EVskIhjwN.FiE2', '2321975.jpeg', '::1', 'Nagpur', '1234567890');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_table`
--
ALTER TABLE `admin_table`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `cart_details`
--
ALTER TABLE `cart_details`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `pending_orders`
--
ALTER TABLE `pending_orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `user_orders`
--
ALTER TABLE `user_orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `user_payments`
--
ALTER TABLE `user_payments`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `user_table`
--
ALTER TABLE `user_table`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_table`
--
ALTER TABLE `admin_table`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `brand_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `pending_orders`
--
ALTER TABLE `pending_orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `user_orders`
--
ALTER TABLE `user_orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user_payments`
--
ALTER TABLE `user_payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user_table`
--
ALTER TABLE `user_table`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
