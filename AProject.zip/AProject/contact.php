<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Contact Details</title>
<!-- Bootstrap CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<style>
body {
    background-color: #f8f9fa;
}

.container {
    margin-top: 50px;
}

.brand-logo {
    max-width: 100px;
    max-height: 100px;
}

.brand-name {
    font-size: 24px;
    font-weight: bold;
    margin-top: 10px;
}

.email, .phone {
    font-size: 18px;
}

.card {
    margin-bottom: 20px;
    position: relative;
    overflow: hidden;
}

.card:hover .background-overlay {
    background: linear-gradient(45deg, #ff8a65, #ff5722, #ff5722, #ff8a65);
    transition: background 0.3s ease;
}

.background-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(45deg, #ff5722, #ff8a65, #ff5722, #ff8a65);
    transition: background 0.3s ease;
    opacity: 0.7;
    z-index: -1;
}

/* Styling for the ripple effect */
.ripple {
    position: absolute;
    border-radius: 50%;
    background-color: rgba(255, 255, 255, 0.3);
    transform: scale(0);
    animation: ripple-animation 0.5s linear;
}

@keyframes ripple-animation {
    to {
        transform: scale(2);
        opacity: 0;
    }
}
</style>
</head>
<body>

<div class="container">
    <div class="row">
        <?php
        // Sample data for demonstration
        $brands = array(
            array(
                'name' => 'Nike',
                'logo' => 'https://cdn.britannica.com/50/213250-050-02322AA8/Nike-logo.jpg',
                'email' => 'nike@example.com',
                'phone' => '123-456-7890'
            ),
            array(
                'name' => 'Adidas',
                'logo' => 'https://cdn.dribbble.com/users/393931/screenshots/15764987/media/1130816cce80225ea2556b8911db6aa0.png?resize=1000x750&vertical=center',
                'email' => 'adidas@example.com',
                'phone' => '987-654-3210'
            ),
            array(
                'name' => 'Skechers',
                'logo' => 'https://sh.skechers.com/logos/images/CORP_SKX_DROP-SHADOW_BLU-logo.jpg',
                'email' => 'skechers@example.com',
                'phone' => '456-789-0123'
            ),
            array(
                'name' => 'Reebok',
                'logo' => 'https://cdn.shopify.com/s/files/1/0558/6413/1764/files/Rewrite_Reebok_Logo_Design_History_Evolution_0_1024x1024.jpg?v=1695309461',
                'email' => 'reebok@example.com',
                'phone' => '789-012-3456'
            ),
            array(
                'name' => 'Woodland',
                'logo' => 'https://static.vecteezy.com/system/resources/previews/020/336/198/non_2x/woodland-logo-woodland-icon-free-free-vector.jpg',
                'email' => 'woodland@example.com',
                'phone' => '234-567-8901'
            )
        );

        foreach ($brands as $brand) {
            echo '
            <div class="col-md-4">
                <div class="card text-center">
                    <img src="' . $brand['logo'] . '" class="card-img-top brand-logo" alt="' . $brand['name'] . ' Logo">
                    <div class="card-body">
                        <h5 class="card-title brand-name">' . $brand['name'] . '</h5>
                        <p class="card-text email">' . $brand['email'] . '</p>
                        <p class="card-text phone">' . $brand['phone'] . '</p>
                        <a href="#" class="btn btn-primary">Contact</a>
                    </div>
                </div>
            </div>';
        }
        ?>
    </div>
</div>

<!-- Bootstrap JS and dependencies -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
$(document).ready(function() {
    $('.card').on('mouseenter', function(e) {
        var ripple = $(this).find('.ripple');
        var posX = e.pageX - $(this).offset().left;
        var posY = e.pageY - $(this).offset().top;
        ripple.css({ left: posX, top: posY, transform: 'scale(0)' }).animate({
            transform: 'scale(2)',
            opacity: 0
        }, 500);
    });
});
</script>
</body>
</html>