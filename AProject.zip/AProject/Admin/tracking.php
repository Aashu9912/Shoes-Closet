<h3 class="text-center text-success">All Products</h3>
<table class="table table-bordered mt-5">
<thead class="bg-info">
<th>Product Id</th>
<th>Order ID</th>
<th>Invoice Number</th>
<th>Order Date</th>
<th>Status</th>
<th>Product Location</th>
</thead>
<tbody class="bg-secondary text-light">
<?php
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_location'])) {
        // Handle form submission to update product location
        $order_id = $_POST['order_id'];
        $new_location = $_POST['product_location'];

        // Update product location in the database
        $update_query = "UPDATE `user_orders` SET `product_location`='$new_location' WHERE `order_id`='$order_id'";
        mysqli_query($con, $update_query);
    }
    $get_products="Select * from `user_orders`";
    $result=mysqli_query($con,$get_products);
    $number=0;
    while($row=mysqli_fetch_assoc($result)){
        $order_id=$row['order_id'];
        $amount_due=$row['amount_due'];
        $invoice_number=$row['invoice_number'];
        $order_date=$row['order_date'];
        $status=$row['order_status'];
        $product_location=$row['product_location'];
        $number++;
        ?>
        <tr class='text-center'>
        <td><?php echo $number ?></td>
        <td><?php echo $order_id ?></td>
        <td><?php echo $invoice_number ?></td>
        <td><?php echo $order_date ?></td>  
        <td>Payment Status <?php echo $status ?></td>   
        <td>
            <form method="post">
                <input type="hidden" name="order_id" value="<?php echo $order_id ?>">
                <input type="text" name="product_location" value="<?php echo $product_location ?>">
                <input type="submit" name="update_location" value="Update" class="btn btn-info px-3 mb-3">
            </form>
        </td>  
        </tr>
    <?php
    }
    ?>
</tbody>
</table>